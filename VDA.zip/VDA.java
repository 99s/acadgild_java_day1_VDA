import java.io.DataInputStream;
class VDA
 {
	public static void main(String args[])
	{
	 //public int a,b,c,d=4;
	 /*using piblic will return an error--
	 "illegal-start-of-expression".
	 Methods can declare only local variables. 
	 That why compiler report an error when you try to declare it as public.

     In case of local variables,
	 you can not use any kind of accessor 
	 (public, protected or private).
	 */
	 int a,b=4,c;
	 a =1;
	 c =7;
	 System.out.println("the 3 variables are : " + a + " & " + b + " & " + c );
	}
 }